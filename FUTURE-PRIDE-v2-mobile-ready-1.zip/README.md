# FUTURE PRIDE
Free original learning platform.

Included:
- Colorful responsive UI
- Student dashboard
- Subjects
- Study planner
- Sample test engine
- Recorded video player
- Supabase login/signup
- Supabase database schema
- LiveKit live classroom token endpoint + VideoConference UI
- Cloudflare Stream secure direct-upload endpoint
- Teacher upload page
- Teacher/Admin dashboard foundations
- No payments

External services required for real cloud functionality:
Supabase, LiveKit Cloud, Cloudflare Stream, Vercel.
