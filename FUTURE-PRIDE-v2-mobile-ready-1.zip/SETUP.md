# FUTURE PRIDE — MOBILE-ONLY SETUP

## Part 1 — Put the project on GitHub
1. Download and extract the ZIP.
2. Open GitHub in Chrome and create a new repository named `future-pride`.
3. Open the repository → Add file → Upload files.
4. Upload ALL extracted project files/folders.
5. Tap Commit changes.

## Part 2 — Supabase (login + database)
1. Open Supabase and create a new project.
2. Open SQL Editor.
3. Create a New query.
4. Open the project's `supabase/schema.sql` file, copy all SQL, paste it into SQL Editor.
5. Tap Run.
6. Open Project Settings → API.
7. Copy Project URL and the public/anon key.

## Part 3 — LiveKit (live classes)
1. Create a LiveKit Cloud project.
2. Open the project's keys/credentials area.
3. Copy WebSocket URL, API key and API secret.
4. Keep the API secret private.

## Part 4 — Cloudflare Stream (recorded video)
1. Open Cloudflare Dashboard and Stream.
2. Create an API token with Stream Write permission.
3. Copy Account ID and token.
4. The project requests a one-time direct-upload URL from the server, so the API token is not sent to the browser.
5. Videos can then be uploaded from the Teacher Upload page.

## Part 5 — Vercel
1. Open Vercel → Add New → Project.
2. Import the `future-pride` GitHub repository.
3. In Environment Variables add:
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
CLOUDFLARE_ACCOUNT_ID
CLOUDFLARE_STREAM_TOKEN
LIVEKIT_URL
LIVEKIT_API_KEY
LIVEKIT_API_SECRET
4. Paste each value exactly.
5. Deploy.
6. If Vercel asks for the framework, leave Next.js/auto-detected.
7. After deployment, open the generated URL.

## Important
- Do not put API secrets in public source files.
- `.env.local` is for local development; Vercel Environment Variables are for the deployed site.
- Payment is intentionally not included.
- The live classroom uses LiveKit. Recorded uploads use Cloudflare Stream. Auth/database use Supabase.
