'use client';
export default function VideoPlayer({src}:{src:string}){return <div style={{background:"#111",borderRadius:18,overflow:"hidden"}}><video src={src} controls playsInline style={{width:"100%",display:"block"}}/></div>}
