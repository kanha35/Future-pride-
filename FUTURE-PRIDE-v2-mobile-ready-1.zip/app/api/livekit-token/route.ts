import {NextRequest,NextResponse} from 'next/server';
import {AccessToken} from 'livekit-server-sdk';
export async function POST(req:NextRequest){
 const {room,identity}=await req.json();
 if(!room||!identity) return NextResponse.json({error:'room and identity are required'},{status:400});
 const token=new AccessToken(process.env.LIVEKIT_API_KEY,process.env.LIVEKIT_API_SECRET,{identity});
 token.addGrant({roomJoin:true,room,canPublish:true,canSubscribe:true});
 return NextResponse.json({token:await token.toJwt(),url:process.env.LIVEKIT_URL});
}
