import {NextResponse} from 'next/server';
export async function POST(){
 const account=process.env.CLOUDFLARE_ACCOUNT_ID;
 const token=process.env.CLOUDFLARE_STREAM_TOKEN;
 if(!account||!token) return NextResponse.json({error:'Cloudflare Stream is not configured'},{status:500});
 const r=await fetch(`https://api.cloudflare.com/client/v4/accounts/${account}/stream/direct_upload`,{
  method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
  body:JSON.stringify({maxDurationSeconds:3600})
 });
 const data=await r.json();
 return NextResponse.json(data,{status:r.status});
}
