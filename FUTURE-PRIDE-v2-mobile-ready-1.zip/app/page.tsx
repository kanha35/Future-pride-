const features=[
["🎥","Live Classes","Join teacher-led interactive classrooms."],
["▶️","Recorded Courses","Watch lectures with a clean video experience."],
["📝","Tests","Chapter quizzes, assignments and mock tests."],
["🤖","AI Doubt Help","Get guided help with difficult questions."],
["📊","Progress","Track marks, streaks and learning progress."],
["📚","Study Material","Organized notes and chapter resources."]
];
export default function Home(){
return <main className="shell">
<header className="top"><div className="logo">FUTURE PRIDE</div><button className="btn">Student Login</button></header>
<section className="hero"><div><span className="badge">100% FREE LEARNING</span><h1>Learn smarter.<br/>Grow stronger.</h1><p>A colorful all-in-one learning platform for classes 6–12 with live classes, recorded lectures, tests, notes and progress tracking.</p><button className="btn">Start Learning</button></div>
<div className="card"><h2>Student Dashboard</h2><p>Today’s progress</p><div className="card">🔥 7 day streak</div><br/><div className="card">📚 3 lessons remaining</div><br/><div className="card">🎯 Test accuracy 86%</div></div></section>
<div className="grid">{features.map(([i,t,d])=><div className="card" key={t}><div style={{fontSize:32}}>{i}</div><h2>{t}</h2><p>{d}</p></div>)}</div>
</main>}
