'use client';
import {useState} from 'react';
export default function Upload(){
 const [status,setStatus]=useState('');
 async function upload(e:React.ChangeEvent<HTMLInputElement>){
  const file=e.target.files?.[0]; if(!file)return;
  setStatus('Creating secure upload URL...');
  const r=await fetch('/api/cloudflare-upload',{method:'POST'}); const d=await r.json();
  if(!r.ok){setStatus(d.error||'Cloudflare setup missing');return;}
  setStatus('Uploading...');
  const u=await fetch(d.result.uploadURL,{method:'POST',body:file});
  setStatus(u.ok?'Uploaded to Cloudflare Stream.':'Upload failed.');
 }
 return <main className="shell"><section style={{maxWidth:700,margin:'60px auto',padding:'0 20px'}}><div className="card"><h1>🎬 Upload Recorded Lecture</h1><p>Select a video. The API token stays on the server.</p><input type="file" accept="video/*" onChange={upload}/><p>{status}</p></div></section></main>
}
