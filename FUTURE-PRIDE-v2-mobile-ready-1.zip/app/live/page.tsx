'use client';
import {useState} from 'react';
import {LiveKitRoom,VideoConference} from '@livekit/components-react';
import '@livekit/components-styles';
export default function Live(){
 const [room,setRoom]=useState('future-pride-demo'); const [name,setName]=useState('Student'); const [token,setToken]=useState<string|null>(null); const [url,setUrl]=useState('');
 async function join(){const r=await fetch('/api/livekit-token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({room,identity:name})});const d=await r.json();setToken(d.token);setUrl(d.url);}
 if(token) return <div style={{height:'100vh'}}><LiveKitRoom token={token} serverUrl={url} connect><VideoConference/></LiveKitRoom></div>;
 return <main className="shell"><section style={{maxWidth:600,margin:'70px auto',padding:'0 20px'}}><div className="card"><h1>📡 Live Class</h1><input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" style={{width:'100%',padding:14,margin:'8px 0'}}/><input value={room} onChange={e=>setRoom(e.target.value)} placeholder="Room name" style={{width:'100%',padding:14,margin:'8px 0'}}/><button className="btn" onClick={join}>Join Live Class</button></div></section></main>
}
