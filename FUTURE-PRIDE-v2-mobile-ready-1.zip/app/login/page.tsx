'use client';
import {useState} from 'react';
import {supabaseBrowser} from '../../lib/supabase-browser';
export default function Login(){
 const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [mode,setMode]=useState<'login'|'signup'>('login'); const [msg,setMsg]=useState('');
 async function submit(){
  const sb=supabaseBrowser();
  const r=mode==='login'?await sb.auth.signInWithPassword({email,password}):await sb.auth.signUp({email,password});
  setMsg(r.error?.message || (mode==='login'?'Logged in!':'Account created. Check email if confirmation is enabled.'));
 }
 return <main className="shell"><section style={{maxWidth:460,margin:'80px auto',padding:'0 20px'}}><div className="card"><div className="logo">FUTURE PRIDE</div><h1>{mode==='login'?'Welcome back':'Create account'}</h1><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%',padding:14,margin:'8px 0',borderRadius:12,border:'1px solid #ddd'}}/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} style={{width:'100%',padding:14,margin:'8px 0',borderRadius:12,border:'1px solid #ddd'}}/><button className="btn" onClick={submit}>{mode==='login'?'Login':'Sign up'}</button><button style={{border:0,background:'none',padding:15}} onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'Create new account':'Already have an account?'}</button>{msg&&<p>{msg}</p>}</div></section></main>
}
